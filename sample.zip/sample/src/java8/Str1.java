package java8;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Str1 {

	public static void main(String[] args) {
		Stream.iterate(1, e -> e + 1)
			.filter(e -> e % 3 == 0)
			.map(e -> e * 2)
			.limit(10)
			.forEach(System.out::println);

		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);

		System.out.println(total(numbers, e -> true));
		System.out.println(total(numbers, e -> e % 2 == 0));
		System.out.println(total(numbers, e -> e % 2 != 0));
		
		Set<String> set = new HashSet<>();

	}

	private static Integer total(List<Integer> numbers, Predicate<Integer> predicate) {
		return numbers.stream()
					.filter(predicate)
					.reduce(0, Integer::sum);
	}

}
