package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Str2Uniq {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("A", "B", "C", "AA", "B");

		list.stream().distinct().forEach(System.out::println);
		
		List<Person> plist = new ArrayList<>();
		Person p1 = new Person(1, "p1");
		Person p2 = new Person(1, "p2");
		Person p3 = new Person(1, "p3");
		Person p4 = new Person(1, "p1");
		Person p5 = new Person(1, "p1");
		Person p6 = new Person(1, "p4");

		System.out.println((p1 == p4) + " " + p1.equals(p4));
		plist.add(p1);
		plist.add(p2);
		plist.add(p3);
		plist.add(p4);
		plist.add(p5);
		plist.add(p6);

		plist.stream().distinct().forEach(System.out::println);
		Set<Person> set = new HashSet<Person>();
		plist.stream().allMatch(p -> set.add(p));
		System.out.println(set);

	}

}

class Person {
	int id;
	String name;

	public Person() {

	}

	public Person(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object p) {
		return (p instanceof Person && this.id == ((Person) p).getId()
				&& this.getName().equals(((Person) p).getName()));
	}

	@Override
	public int hashCode() {
		return this.id;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + "]";
	}

}