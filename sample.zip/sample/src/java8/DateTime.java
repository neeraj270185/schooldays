package java8;

import java.time.LocalDate;
import java.time.ZoneId;

public class DateTime {

	public static void main(String[] args) {
		LocalDate now = LocalDate.now();
		System.out.println(now);

		LocalDate then = LocalDate.of(2_0_2_0, 0_4, 2_0);
		System.out.println(then);

		LocalDate kolkata = LocalDate.now(ZoneId.of("Asia/Kolkata"));
		System.out.println("kolkata " + kolkata);

		LocalDate _nthday_of_yr = LocalDate.ofYearDay(2016, 365);
		System.out.println("_nthday_of_yr " + _nthday_of_yr);
	}

}
