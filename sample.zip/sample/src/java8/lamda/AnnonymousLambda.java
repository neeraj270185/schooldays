package java8.lamda;

public class AnnonymousLambda {
	public static void main(String[] args) {
		MyInterface m = () -> System.out.println("m1");
		m.m1();
		m.m2();
		MyInterface.m3();
		Runnable r = () -> System.out.println("running");
		
	}
}
