package java8.lamda;

@FunctionalInterface
public interface MyInterface {
	public void m1();

	public default void m2() {
		System.out.println("MyInterface.default");
	}

	public static void m3() {
		System.out.println("MyInterface.static");
	}
}
