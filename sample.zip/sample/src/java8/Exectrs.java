package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;

public class Exectrs {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService service = Executors.newFixedThreadPool(3);
		
		List<Future<String>> resultList = new ArrayList<>();
		
		resultList.add(service.submit(() -> {
			System.out.println(Thread.currentThread()+" finished");
			return Thread.currentThread()+" finished";
		}));
		
		resultList.add(service.submit(() -> {
			System.out.println(Thread.currentThread()+" finished");
			Thread.sleep(5000);
			return Thread.currentThread()+" finished";
		}));
		
		resultList.add(service.submit(() -> {
			System.out.println(Thread.currentThread()+" finished");
			return Thread.currentThread()+" finished";
		}));
		
		Function<Future<String>, String> func = new Function<Future<String>, String>() {
			
			@Override
			public String apply(Future<String> t) {
				
				try {
					return t.get(2, TimeUnit.SECONDS);
				} catch (InterruptedException e) {
					throw new RuntimeException(e.getMessage());
				} catch (ExecutionException e) {
					throw new RuntimeException(e.getMessage());
				} catch (TimeoutException e) {
					System.out.println("timedout for "+ t.toString());
					throw new RuntimeException(e.getMessage());
				}
			}
		};
		
		System.out.println();
		resultList.stream()
					.map(e -> func.apply(e))
					.forEach(System.out::println);
		
		service.shutdownNow();
	}

}
class Task implements Callable<String>{

	int id;
	
	public Task(int id) {
		this.id = id;
	}
	
	@Override
	public String call() throws Exception {
		return id+" task ran, and ended.";
	}
	
}
