package java8;

import java.util.ArrayList;
import java.util.List;

public class Lam1 {

	public static void main(String[] args) {
		Thread t = new Thread(()-> {
			System.out.println("running in thread");
			
			
		}, "t1");
		t.start();
		
		List<String> list = new ArrayList<>();
		list.stream();
	}

}
