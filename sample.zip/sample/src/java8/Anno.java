package java8;

public @interface Anno {

}
