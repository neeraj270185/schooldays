package cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppCache<K, T> {

	private long timeToLive;
	private int maxItem;
	private Map<String, CacheObject> cacheMap;

	protected class CacheObject {
		public long lastAccessed = System.currentTimeMillis();
		public T value;

		protected CacheObject(T value) {
			this.value = value;
		}
		
		@Override
		public String toString() {
			return this.value.toString();
		}
	}

	public AppCache(final long timeToLive, final int maxItem) {
		this.timeToLive = timeToLive;
		this.maxItem = maxItem;
		cacheMap = new HashMap<String, CacheObject>(maxItem);

		Thread t = new Thread(() -> {
			while (true) {
				showCache();
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				cleanUp();
			}
		});

		t.setDaemon(true);
		t.start();

	}

	private void showCache() {
		System.out.println(System.currentTimeMillis() + " - " + cacheMap);
	}

	private void cleanUp() {
		long now = System.currentTimeMillis();

		List<String> delList = new ArrayList<>();

		synchronized (cacheMap) {
			Set<String> keys = cacheMap.keySet();
			for (String key : keys) {
				CacheObject co = cacheMap.get(key);
				if (now > (co.lastAccessed + this.timeToLive))
					delList.add(key);
			}
		}

		for (String key : delList) {
			cacheMap.remove(key);
			System.out.println(key + " removed as expired");
		}
	}

	public void put(K key, T value) {
		if(cacheMap.size() >= maxItem) {
			System.out.println("Cache capacity is full");
		}
		synchronized (cacheMap) {
			cacheMap.put((String) key, new CacheObject(value));
			
		}
	}

	public T get(K key) {
		synchronized (cacheMap) {
			CacheObject co = cacheMap.get(key);

			if (co == null)
				return null;
			else {
				co.lastAccessed = System.currentTimeMillis();
				return co.value;
			}

		}
	}

	public void remove(K key) {
		synchronized (cacheMap) {
			cacheMap.remove(key);
			System.out.println(key + " removed");
		}
	}

	public static void main(String[] args) throws InterruptedException {
		AppCache<String, String> cache = new AppCache<>(10000, 100);
		
		cache.put("G", "Google");
		cache.put("I", "Intex");
		cache.put("A", "Apple");
		cache.put("B", "Birlasoft");
		cache.put("C", "Cyent");
		Thread.sleep(5000);
		cache.put("D", "Doodle");
		cache.put("E", "EMC2");
		cache.put("F", "");
		cache.put("H", "HCL");
		cache.put("J", "Joke");
		Thread.sleep(5000);
		cache.put("K", "Kean India");
		cache.put("L", "Limca");
		cache.put("M", "Mahindra");
		cache.put("N", "Newgen");
		cache.put("O", "oxford");
		Thread.sleep(5000);
		cache.put("P", "People");
		cache.put("S", "Sapient");
		
	}
}
