package sample;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomInt {

	public static void main(String[] args) {
		AtomicInteger ai = new AtomicInteger();
		
		System.out.println(ai.incrementAndGet());
	}

}
