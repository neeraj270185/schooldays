package sample;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Test {

	public static void main(String[] args) {
		Map<String, String> map = new ConcurrentHashMap<>();
		map.put("1", "A");
		

	}

}
