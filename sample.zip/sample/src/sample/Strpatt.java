package sample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Strpatt {

	public static void main(String[] args) {
		String s1 = "ahelloadsfdsahelloladfhhelloahaahellooo";
		
		Pattern pattern = Pattern.compile("hello");
		
		Matcher matcher = pattern.matcher(s1);
		int ctr=0;
		while(matcher.find()){
			System.out.println("found");
			ctr++;
		}
		System.out.println(ctr);
		
		System.out.println(s1.substring(5, 0));
	}
	

}
