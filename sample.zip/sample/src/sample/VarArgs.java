package sample;

public class VarArgs {

	
	public static void main(String[] args) {
		VarArgs va = new VarArgs();
		va.print(1);
		va.print(1, 2);
		va.print(1, 2, 3, 4, 5);
		va.print("abc", 1, 2, 3, 4, 5);
	}

	void print(int... i) {
		System.out.println("VA: " + i);
	}

	void print(String s, int... j) {
		System.out.println("VA2: " + s+j);
	}

}
