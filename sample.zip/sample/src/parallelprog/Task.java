package parallelprog;

import java.util.Random;
import java.util.concurrent.Callable;

public class Task implements Callable<String> {

	int id=0;

	public Task(int id) {
		this.id = id;
	}

	@Override
	public String call() throws Exception {
		Random random = new Random();

		long result = 0, i = 0;
		while (i <= 100000000) {
			result += random.nextInt(100000000);
			i++;
		}
		return "done " + this.id + " "+result;
	}

}
