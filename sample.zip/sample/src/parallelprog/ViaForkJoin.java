package parallelprog;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ViaForkJoin extends RecursiveTask<String> {

	private static final long serialVersionUID = 1L;
	private static final int SEQUENTIAL_THRESHOLD = 2;
	final static int FACTOR = 100;

	private Task[] tasks;
	private int start;
	private int end;

	public ViaForkJoin(Task[] tasks, int start, int end) {
		this.tasks = tasks;
		this.start = start;
		this.end = end;
	}

	public ViaForkJoin(Task[] tasks) {
		this(tasks, 0, tasks.length);
	}

	@Override
	protected String compute() {
		final int length = end - start;
		if (length < SEQUENTIAL_THRESHOLD) {
			return computeDirectly();
		}
		final int split = length / 2;

		final ViaForkJoin left = new ViaForkJoin(tasks, start, start + split);
		left.fork();
		final ViaForkJoin right = new ViaForkJoin(tasks, start + split, end);
		return right.compute() + left.join();
	}

	private String computeDirectly() {
		System.out.println(Thread.currentThread() + " computing: " + start + " to " + end);
		StringBuilder res = new StringBuilder();
		for (int i = start; i < end; i++)
			try {
				res.append(tasks[i].call());
			} catch (Throwable e) {
				System.err.println(e.getMessage());
			}
		return res.toString();
	}

	public static void main(String[] args) {
		StopWatch stopWatch = new StopWatch(ViaForkJoin.class.getName());

		stopWatch.begin();

		Task[] tasks = new Task[FACTOR];

		for (int i = 0; i < FACTOR; i++)
			tasks[i] = new Task(i);

		final ForkJoinPool fjPool = new ForkJoinPool(100);

		ViaForkJoin fj = new ViaForkJoin(tasks);

		System.out.println(fjPool.invoke(fj));

		stopWatch.stop();
	}

}
