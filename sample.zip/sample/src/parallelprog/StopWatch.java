package parallelprog;

public class StopWatch {
	private long start, end;
	private String name = "noname";

	public StopWatch() {

	}

	public StopWatch(String name) {
		this.name = name;
	}

	public void begin() {
		start = System.currentTimeMillis();
	}

	public void stop() {
		end = System.currentTimeMillis();

		System.out.println(name + " time taken in millis: " + (end - start));

	}
}
