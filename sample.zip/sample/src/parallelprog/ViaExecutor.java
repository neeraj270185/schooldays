package parallelprog;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.IntStream;

public class ViaExecutor {
	final static int FACTOR = 100;

	public static void main(String[] args) throws ExecutionException, InterruptedException {
		ExecutorService executor =  Executors.newFixedThreadPool(50);
				new ForkJoinPool(Runtime.getRuntime().availableProcessors(), ForkJoinPool.defaultForkJoinWorkerThreadFactory, null, true);

		StopWatch stopWatch = new StopWatch(ViaExecutor.class.getName());

		stopWatch.begin();

		List<Future<String>> resultList = new ArrayList<>();

		IntStream.range(0, FACTOR).forEach(i -> {
			Task t1 = new Task(i);
			resultList.add(executor.submit(t1));
		});

		resultList.stream().map(f -> getFromFuture.apply(f)).forEach(System.out::println);

		executor.shutdown();
		stopWatch.stop();

	}

	static Function<Future<String>, String> getFromFuture = new Function<Future<String>, String>() {

		@Override
		public String apply(Future<String> t) {

			try {
				return t.get(5, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				throw new RuntimeException(e.getMessage());
			} catch (ExecutionException e) {
				throw new RuntimeException(e.getMessage());
			} catch (TimeoutException e) {
				System.out.println("timedout for " + t.toString());
				throw new RuntimeException(e.getMessage());
			}
		}
	};

}
