package java7;
/**
 * 
 * ARM - automatic resource management
 * 
 * Autoclosable
 * @author nku103
 *
 */
public class Resource implements AutoCloseable{

	public static void main(String[] args) throws Exception {
		try(Resource r1 = new Resource();){
		
		r1.doStuff();
		r1.doMess();
		}
		
	}

	@Override
	public void close() throws Exception {
		System.out.println("closed connection");
	}
	
	public void doStuff() {
		System.out.println("job done");
	}
	
	public void doMess() throws RuntimeException{
		System.out.println("messed up");
		throw new RuntimeException();
	}

}
