package java7;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ForkJoinTest {

	public static void main(String[] args) {
		final int PROCESSOR = Runtime.getRuntime().availableProcessors();
		System.out.println(PROCESSOR);

		ForkJoinPool pool = new ForkJoinPool(PROCESSOR);

	}

}

class TaskProcessor extends RecursiveTask<List<String>> {

	private static final long serialVersionUID = 1L;

	String file;

	public TaskProcessor(String file) {
		this.file = file;
	}

	@Override
	protected List<String> compute() {

		List<TaskProcessor> tasks = new ArrayList<>();

		File f = new File(file);
		File content[] = f.listFiles();

		if (content != null) {
			for (File file : content) {
				TaskProcessor task = new TaskProcessor(file.getAbsolutePath());
				task.fork();
				tasks.add(task);
			}
		}

		if (tasks.size() > 50) {
			System.out.printf("%s: %d tasks ran.\n", f.getAbsolutePath(), tasks.size());
		}
		return null;
	}

}