package java7;

public class Java7Features {

	public static void main(String[] args) {
		/*
		 * Underscores in numeric literals
		 */
		int big_salary = 5_00_00_000;
		
		System.out.println(big_salary);
		
		/*
		 * Strings in switch 
		 */
		String s="abc";
		switch(s) {
			case "abc":
				System.out.println("got it");
				
			default: 
				System.out.println("i'm default");
		}
		
		
		/*
		 * Binary literals
		 */
		int binary = 0b1001_1001;
		System.out.println(binary);
		
		/*
		 * Try with Resources or ARM (Automatic Resource Management) - close not required in finally
		 * 
		 * Multiple exception catching
		 */
		// catch (FirstException | SecondException ex) {}
		
		/*
		 * SafeVarargs
		 * 
		 * @SuppressWarnings({"unchecked", "varargs"}) to @SafeVarargs
		 */
	}

}
