package conc;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Latch {

	public static void main(String[] args) {
		CountDownLatch latch = new CountDownLatch(3);
		ExecutorService executor = Executors.newFixedThreadPool(2);

		/*
		 * executor.submit(() -> { new Task(latch); return "r1 done"; });
		 * executor.submit((latch) -> Task);
		 */
		executor.submit(() -> {
			new Task(latch);
		});
		executor.submit(() -> {
			new Task(latch);
		});
		executor.submit(() -> {
			new Task(latch);
		});

		/*
		 * executor.submit(new Task(latch)); executor.submit(new Task(latch));
		 * executor.submit(new Task(latch));
		 */

		try {
			latch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done");
	}

}

class Task implements Runnable {

	private CountDownLatch latch;

	public Task(CountDownLatch latch) {
		this.latch = latch;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread() + " started");
		try {
			Thread.sleep(2000);
			this.latch.countDown();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}