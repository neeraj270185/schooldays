package conc;

import java.util.Queue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

public class RejectedThreadEx {
	public static Queue<Runnable> runnable_queue = new LinkedBlockingQueue<Runnable>();

	public static void main(String[] args) {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(3);
		executor.setRejectedExecutionHandler(new RejectedHandler());
		
		executor.submit(new Task3());
		executor.submit(new Task3());
		executor.shutdown();
		executor.submit(new Task3());
	}

}

class Task3 implements Runnable {

	public void run() {
		System.out.println(Thread.currentThread() + " executed.");
	}
}

class RejectedHandler implements RejectedExecutionHandler {

	@Override
	public void rejectedExecution(Runnable task, ThreadPoolExecutor executor) {

		System.out.println("need to complete the rejected task..");
		// Implementations may even decide to queue the task for deferred
		// execution.
		System.out.println("Adding rejected task to runnable queue -- " + RejectedThreadEx.runnable_queue.add(task));

	}

}