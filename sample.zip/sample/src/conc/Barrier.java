package conc;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Barrier {

	public static void main(String[] args) {
		
		CyclicBarrier cb = new CyclicBarrier(3, () -> {
			System.out.println("barrier final process..");
		});
		
		ExecutorService executor = Executors.newFixedThreadPool(3);
		
		/*executor.submit(() ->{
			new Task2(cb);
		});
		
		executor.submit(() ->{
			new Task2(cb);
		});
		
		executor.submit(() ->{
			new Task2(cb);
		});
		*/
		executor.submit(new Task2(cb));
		executor.submit(new Task2(cb));
		executor.submit(new Task2(cb));
	//	cb.reset();
		executor.submit(new Task2(cb));
		executor.submit(new Task2(cb));
		executor.submit(new Task2(cb));
		executor.shutdown();
		
	}

}

class Task2 implements Runnable {

	private CyclicBarrier cb;

	public Task2(CyclicBarrier cb) {
		this.cb = cb;
	}

	@Override
	public void run() {
		System.out.println(cb.getNumberWaiting());
		System.out.println(Thread.currentThread() + " started");
		try {
			Thread.sleep(2000);
			cb.await(1000, TimeUnit.SECONDS);
			
			
		} catch (InterruptedException | BrokenBarrierException | TimeoutException e) {
			e.printStackTrace();
		}
	}

}